//browserify src/chrome/minimatch-node.js > src/chrome/minimatch.js
var minimatch = require("minimatch")
window.minimatch = minimatch