var langPack = {
	up: chrome.i18n.getMessage('showButtonLabel'),
}